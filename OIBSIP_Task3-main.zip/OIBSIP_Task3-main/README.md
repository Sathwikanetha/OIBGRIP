# OIBSIP_Task3
TASK-3:- [To-do WebApp](https://github.com/Anjalimishra14/OIBSIP_Task3/commit/4bc1c1a4a6c2c3e55af88a438bc4588379595fd3)(It is a Oasis Infobyte Level 2 Task 3 of code to develop a To-Do WebApp. It is written using HTML, CSS and JavaScript. It is a single page web app that lets users manage a simple list of tasks. Here users can add and remove tasks from the list.)
